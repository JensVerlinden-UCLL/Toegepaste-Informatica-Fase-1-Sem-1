#FUNCTIE 1

def calculeer_totaal_aantal_goals_per_speler():

    #variabelen definieren
    input_lijst = []
    gefragmenteerde_input_lijst = []
    spelersnamen_set = set()
    output_lijst = []  
    
    
    #input binnenhalen
    fp = open("input.txt", "r", encoding='latin-1')
    
    input_lijst = [x.strip() for x in fp.read().splitlines()]
    
    fp.close()
    
    #input elementen nog eens splitten
    for i in input_lijst:
        gefragmenteerde_input_lijst.append(i.split(";"))

    #laatste lege strings uit sublists verwijderen

    for i in gefragmenteerde_input_lijst:
        i.pop(-1)    
    
    #verschillende spelers wegschrijven in set
    for i in gefragmenteerde_input_lijst:
        spelersnamen_set.add((i[0], i[1]))
    
    #aantal goals berekenen
    for i in spelersnamen_set:
        aantal_goals = 0
    
        for j in gefragmenteerde_input_lijst:
            if j[0] == i[0] and j[1] == i[1]:
                aantal_goals += int(j[3])
    
        output_lijst.append([i[0], i[1], str(aantal_goals)])
    
    
    #resultaten wegschrijven naar csv
    fp = open("resultaten.csv", "w", encoding='latin 1')
    
    for i in output_lijst:
        fp.write(";".join(i) + "\n")
    
    fp.close()

#FUNCTIE 2

def geef_niet_uigesloten_landen(uitgesloten_landen):

    #variabelen definieren
    input_lijst = []
    gefragmenteerde_input_lijst = []
    landen_set = set()

    #input binnenhalen
    fp = open("input.txt", "r", encoding='latin-1')
    
    input_lijst = [x.strip() for x in fp.read().splitlines()]
    
    fp.close()
    
    #input elementen nog eens splitten
    for i in input_lijst:
        gefragmenteerde_input_lijst.append(i.split(";"))
    
    #laatste lege strings uit sublists verwijderen

    for i in gefragmenteerde_input_lijst:
        i.pop(-1) 

    #alle landen wegschrijven in set
    for i in gefragmenteerde_input_lijst:
        landen_set.add(i[2])

    #uitgesloten landen wegfilteren
    landen_set -= set(uitgesloten_landen)

    #gefilterde set als tuple returnen
    return tuple(landen_set)

#TESTCASES

calculeer_totaal_aantal_goals_per_speler()
print(geef_niet_uigesloten_landen(["Nederland", "Portugal"]))