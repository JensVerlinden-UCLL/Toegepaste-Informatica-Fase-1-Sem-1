#FUNCTIE 1

def index_kleinste(lijst, i):
    assert isinstance(lijst, list) and isinstance(i, int), 'Geen list en/of integer meegegeven'

    if i >= len(lijst) or i < 0:
        return -1
    
    return lijst.index(min(lijst[i:]))

#FUNCTIE 2

def verwissel(lijst, i):
    assert isinstance(lijst, list) and isinstance(i, int), 'Geen list en/of integer meegegeven'

    if not(i >= len(lijst) - 1 or i < 0):
        hulp_lijst = lijst[:]
        hulpvariabele = lijst[i]
        hulpindex = index_kleinste(lijst, i)
        if hulpindex == i:
            return
        lijst.pop(i)        
        lijst.pop(hulpindex-1)
        lijst.insert(i, hulp_lijst[hulpindex])
        lijst.insert(hulpindex, hulpvariabele)

def sorteer(lijst):
    assert isinstance(lijst, list), 'Geen list meegegeven'

    for i in range(len(lijst)-1):
        verwissel(lijst, i)

#LIJST VOOR TESTCASES

lijst = [1,5,4,8,2,9] 

#TESTCASES FUNCTIE 1

# print(index_kleinste(lijst, 2))

# print(index_kleinste(lijst, -2))

# print(index_kleinste(lijst, 6))

#TESTCASES FUNCTIE 2

# verwissel(lijst, 2)

# print(lijst)

# verwissel(lijst, -2)

# print(lijst)

#TESTCASES FUNCTIE 3

# sorteer(lijst)

# print(lijst)






