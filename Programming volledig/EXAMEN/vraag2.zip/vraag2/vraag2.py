#KLASSEN DEFINIËREN MET EXTRA ASSERTS OM INPUT TE CONTROLEREN

class Film:
    def __init__(self, input_titel, input_speelduur):
        assert isinstance(input_titel, str) and len(input_titel) > 0 and isinstance(input_speelduur, int), "Geen correcte parameters meegegeven met constructor"
        assert input_speelduur >= 60, "De speelduur moet minimaal 60 minuten zijn"

        self.titel = input_titel
        self.speelduur = input_speelduur
        self.rating = 0

    def zet_rating(self, getallenlijst):
        assert isinstance(getallenlijst, list) or isinstance(getallenlijst, set) or isinstance(getallenlijst, tuple), "Geen iterable meegegeven met methode"
        
        som = 0
        aantal = 0

        for i in getallenlijst:
            if i >= 0 and i <= 5:
                som += i
                aantal += 1

        if aantal != 0:
            self.rating = som/aantal
    
    def __str__(self):
        aantal_uur = self.speelduur // 60
        aantal_minuten = self.speelduur % 60
        return f"Film: {self.titel} ({aantal_uur}u{aantal_minuten}min; rating: {self.rating})"

    def __eq__(self, other):
        if not(isinstance(other, self.__class__)):
            return False
        
        return self.titel == other.titel

class Zaal:

    def __init__(self, input_nummer):
        assert isinstance(input_nummer, int) and input_nummer >= 0, "Geen positieve integer meegegeven met constructor als zaalnummer"

        self.nummer = input_nummer
        self.film = None

    def zet_film(self, input_film):
        assert isinstance(input_film, Film), "Geen Film-object meegegeven met methode"
        
        if self.film == None:
            self.film = input_film

    def verwijder_film(self):
        self.film = None

    def vergelijk_zaalfilms(self, vergelijkinszaal):

        assert isinstance(vergelijkinszaal, Zaal), "Geen Zaal-object meegegeven met methode"

        if self.film != None and self.film == vergelijkinszaal.film:
            return True
        
        return False

    def zet_rating(self, getallenlijst):
        if self.film != None:
            self.film.zet_rating(getallenlijst)

    def __str__(self):
        if self.film != None:
            return f"Zaal: {self.nummer}\n{self.film}"

        return f"Zaal: {self.nummer}\nFilm: Geen film gekoppeld aan de zaal!"

#HULP FUNCTIE OM VERGELIJKING VAN ZAALFILMS OM TE ZETTEN NAAR STRINGOUTPUT

def vergelijk_zaalfilms_output(zaal1, zaal2):

    if zaal1.vergelijk_zaalfilms(zaal2):
        return f"In zaal met nummer {zaal1.nummer} speelt dezelfde film als de film in zaal met nummer {zaal2.nummer}"
    
    return f"In zaal met nummer {zaal1.nummer} speelt een andere film dan de film in zaal met nummer {zaal2.nummer}"

#APP MET TESTCASES

frozen = Film("Frozen", 135)

zaal12 = Zaal(12)

zaal14 = Zaal(14)

zaal12.zet_film(frozen)

zaal14.zet_film(frozen)

print(vergelijk_zaalfilms_output(zaal12, zaal14))

assepoester = Film("Assepoester", 110)

zaal11 = Zaal(11)

zaal11.zet_film(assepoester)

print(vergelijk_zaalfilms_output(zaal14, zaal11))

zaal12.zet_rating([1,2,3,4,10,5,1,2,3,4,5,20])

zaal14.zet_rating([5,5,5,5,5])

print(zaal12)




