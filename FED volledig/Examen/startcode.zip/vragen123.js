const citaten = [
  {
    titel: 'foolish',
    citaat: 'Stay hungry, stay foolish.',
    auteur: 'Steve Jobs',
    taal: 'en'
  },
  {
    titel: 'count days',
    citaat: "Don't count the days, make the days count.",
    auteur: 'Muhammad Ali',
    taal: 'en'
  },
  {
    titel: 'overwinnen',
    citaat: 'Veni, vidi, vici.',
    auteur: 'Julius Caesar',
    taal: 'la'
  },
  {
    titel: 'schatbewaarder',
    citaat: 'De Vlamingen zijn de schatbewaarders van de Nederlandse taal',
    auteur: 'Jan de Hartog',
    taal: 'nl'
  },
  {
    titel: 'vandaag',
    citaat: 'Wat je vandaag moet doen, moet je doen zoals je morgen denkt dat je het had moeten doen.',
    auteur: 'Toon Hermans',
    taal: 'nl'
  },
  {
    titel: 'humor',
    citaat: 'Gevoel voor humor begint bij gevoel voor verdriet.',
    auteur: 'Toon Hermans',
    taal: 'nl',
  },
  {
    titel: 'aimer',
    citaat: "Le verbe aimer est difficile à conjuguer : son passé n'est pas simple, son présent n'est qu'indicatif, et son futur est toujours conditionnel.",
    auteur: 'Jean Cocteau',
    taal: 'fr'
  },
  {
    titel: 'équipe',
    citaat: "Les performances individuelles, ce n'est pas le plus important. On gagne et on perd en équipe.",
    auteur: 'Zinedine Zidane',
    taal: 'fr'
  }

];

// hier komt de rest van je JS code voor vragen 1, 2 en 3