touch private
chmod 740 private
touch public
chmod 664 public
