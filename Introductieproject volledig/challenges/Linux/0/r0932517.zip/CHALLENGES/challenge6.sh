cat secret.txt | tr '[a-z]' '[bgimojstwzcrhuadvlfxqeynpk]' > encrypted.txt
