sha1sum original.txt | cut -f 1 -d " " > hash.txt
