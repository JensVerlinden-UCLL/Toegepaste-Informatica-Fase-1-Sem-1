for i in {001..999}; do mv 'file'$i 'file'$i'd'; done

