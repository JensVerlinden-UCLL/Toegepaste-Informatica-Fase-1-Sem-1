find data -type f -name "*.js" > js-files.txt
