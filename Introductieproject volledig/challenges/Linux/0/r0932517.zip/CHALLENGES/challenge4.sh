echo -n $(cat a.bf)$(cat b.bf)$(cat c.bf)  >> abc.bf
