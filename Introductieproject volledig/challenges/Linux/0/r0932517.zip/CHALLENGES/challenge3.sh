cut -d' ' -f 2,5 data.dat > summary.dat
